﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("첫번째 값을 입력하세요.:");
            string input = Console.ReadLine();
            float inputNumber = Convert.ToSingle(input);
            Console.Write("두번째 값을 입력하세요.:");
            string input2 = Console.ReadLine();
            float inputNumber2 = Convert.ToSingle(input2);

            Calculator calc = new Calculator();
            calc.Plus(inputNumber, inputNumber2);
            calc.Minus(inputNumber, inputNumber2);
            calc.Multiply(inputNumber, inputNumber2);
            calc.Divine(inputNumber, inputNumber2);
        }
    }

    class Calculator // 계산기 클래스
    {
        /// <summary>
        /// 플러스에서 필요한 녀석들 기존 값 : a , 추가될 값 : b
        /// </summary>
        public void Plus(float a, float b)
        {
            float result = a + b;
            Console.WriteLine($"{a} + {b} = {result}");
            //Console.WriteLine($"{a} + {b} = {a + b}");
        }
        /// <summary>
        /// 뺄셈에 필요한 녀석들 기존 값 : a , 뺄 값 : b
        /// </summary>
        public void Minus(float a, float b)
        {
            float result = a - b;
            Console.WriteLine($"{a} - {b} = {result}");
        }
        /// <summary>
        /// 곱셈에 필요한 녀석들 기존 값 : a , 곱할 값 : b
        /// </summary>
        public void Multiply(float a, float b)
        {
            float result = a * b;
            Console.WriteLine($"{a} * {b} = {result}");
        }
        /// <summary>
        /// 나눗셈에 필요한 녀석들 기존 값 : a , 나눌 값 : b
        /// </summary>
        public void Divine(float a, float b)
        {
            float result = a / b;
            Console.WriteLine($"{a} / {b} = {result}");
        }
    }
}
