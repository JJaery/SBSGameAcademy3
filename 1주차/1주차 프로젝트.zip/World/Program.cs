﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello
{
    class Program
    {
        static void Main(string[] args)
        {
            Person.SayPerson();

            Person test1 = new Person();
            Person.PeopleCount = 1;
            test1.name = "인재";
            test1.age = 18;
            test1.Say();


            Person test2 = new Person();
            Person.PeopleCount = 2;
            test2.name = "영미";
            test2.age = 17;
            test2.Say();

            Console.WriteLine(Person.PeopleCount);

        }
    }

    class Person
    {
        public static int PeopleCount;

        public string name;
        public int age;

        public static void SayPerson()
        {
            Console.WriteLine("사람 : Person이다.");
        }

        public void Say()
        {
            Console.WriteLine("나는 ~~이고 ~살이야");
            Console.WriteLine($"나는 {name}이고 {age}살이야");
            Console.WriteLine("나는 " + name + "이고 " + age + "살이야");
            Console.WriteLine("나는 {0}이고 {1}살이야", name, age);
            Console.WriteLine(string.Format("나는 {0}이고 {1}살이야", name, age));
        }
    }


}