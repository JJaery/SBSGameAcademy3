﻿using System;

namespace HelloWorld
{
    class Person
    {

    }
    class Program
    {
        static int number = 10;
        static float number2 = 1.11f;
        static string name = null;

        static void Main(string[] args)
        {
            Console.WriteLine(name);
            Console.WriteLine(number);
            Console.WriteLine(number2);
            Calc2();
            Calc3();
        }

        static void Calc2()
        {
            Console.WriteLine("Calc 기능 수행됨");
            Console.WriteLine("Calc 기능 수행됨1");
        }
        static void Calc3()
        {
            Console.WriteLine("Hello World");
        }

    }
}