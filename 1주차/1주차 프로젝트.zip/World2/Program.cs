﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    class Program
    {
        static void Main(string[] args)
        {
            Person test1 = new Person();
            test1.Set("인재", 18);
            test1.Say();

            Person test2 = new Person();
            test2.SetName("영미");
            test2.SetAge(17);
            test2.Say();

            Person test3 = new Person();
            test3.name = "철수";
            test3.age = 16;
            test3.Say();

            test1.SayTo(test2);
        }
    }

    class Person
    {
        public string name;
        public int age;

        /// <summary>
        /// 상대방에게 말을 거는 행동
        /// </summary>
        /// <param name="target">말을 걸 상대방</param>
        public void SayTo(Person target)
        {
            Console.WriteLine($"{name}({age})이가 {target.name}({target.age})에게 말을 겁니다.");
        }

        /// <summary>
        /// Person의 데이터를 세팅하는 메소드
        /// </summary>
        /// <param name="tempName">이름</param>
        /// <param name="tempAge">나이</param>
        public void Set(string tempName, int tempAge)
        {
            name = tempName;
            age = tempAge;
        }

        public void SetName(string tempName)
        {
            name = tempName;
        }
        public void SetAge(int tempAge)
        {
            age = tempAge;
        }

        public void Say()
        {
            Console.WriteLine($"나는 {name}이고 {age}살이야");
        }
    }

}
